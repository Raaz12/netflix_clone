import { SafeAreaView, StyleSheet, Text, View } from "react-native";
import React from "react";

const DetailsPage = ({ route }) => {
  const { data } = route?.params;
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <Text>DetailsPage </Text>
    </SafeAreaView>
  );
};

export default DetailsPage;

const styles = StyleSheet.create({});
