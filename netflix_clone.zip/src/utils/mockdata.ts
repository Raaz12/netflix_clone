export const mockData = {
    posts: [
        {
            user: {
                name: "Russell Peters",
                avatar: "https://bit.ly/dan-abramovss",
            },
            post: {
                statistics: {
                    view_count: 1034,
                    like_count: 654,
                    dislike_count: 0,
                    comment_count: 298,
                    favourite_count: 89,
                },
                _id: "asdasdasdasdasdasdads",
                account_id: "asdasdasdasdads",
                platform_id: "asdasdasdasdasdasd",
                media: [
                    {
                        type: "image",
                        src: "https://loremflickr.com/480/350",
                        decsription: "Sample image",
                    }
                ],
                published_at: "Sat Jun 10 2023 23:07:49 GMT+0530 (India Standard Time)",
                title: "Peters",
                description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an",
                language: "en",
                tags: ["lorem", "ipsum"],
                live_broadcast: false,
                created_at: "Sat Jun 10 2023 23:07:49 GMT+0530 (India Standard Time)",
                deleted: false,
                updated_at: "Sat Jun 10 2023 23:07:49 GMT+0530 (India Standard Time)"
            }
        },
        {
            user: {
                name: "Dianne Russell",
                avatar: "https://bit.ly/dan-abramovss",
            },
            post: {
                statistics: {
                    view_count: 1034,
                    like_count: 654,
                    dislike_count: 0,
                    comment_count: 298,
                    favourite_count: 89,
                },
                _id: "asdasdasdasdasdasdads",
                account_id: "asdasdasdasdads",
                platform_id: "asdasdasdasdasdasd",
                media: [
                    {
                        type: "image",
                        src: "https://loremflickr.com/480/350",
                        decsription: "Sample image",
                    }
                ],
                published_at: "Sat Jun 10 2023 23:07:49 GMT+0530 (India Standard Time)",
                title: "Dianne",
                description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an",
                language: "en",
                tags: ["lorem", "ipsum"],
                live_broadcast: false,
                created_at: "Sat Jun 10 2023 23:07:49 GMT+0530 (India Standard Time)",
                deleted: false,
                updated_at: "Sat Jun 10 2023 23:07:49 GMT+0530 (India Standard Time)"
            }
        }
    ]
}