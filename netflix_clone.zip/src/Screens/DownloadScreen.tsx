import { SafeAreaView, StyleSheet, Text, View } from "react-native";
import React from "react";
import { Theme } from "../Theme";

const DownloadScreen = () => {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: Theme.black }}>
      <Text>DownloadScreen</Text>
    </SafeAreaView>
  );
};

export default DownloadScreen;

const styles = StyleSheet.create({});
