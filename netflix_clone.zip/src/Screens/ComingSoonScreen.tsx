import { SafeAreaView, StyleSheet, Text, View } from "react-native";
import React from "react";
import { Theme } from "../Theme";

const ComingSoonScreen = () => {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: Theme.black }}>
      <Text>ComingSoonScreen</Text>
    </SafeAreaView>
  );
};

export default ComingSoonScreen;

const styles = StyleSheet.create({});
