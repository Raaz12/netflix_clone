export const useFont = {
  NotoSans: require("../Assets/fonts/NotoSans-VariableFont_wdth,wght.ttf"),
};
