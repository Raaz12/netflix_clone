export const Theme = {
  inActiveColor: "#989898",
  Main_Color: "#47969F",
  Primary: "#4C7CA9",
  white: "#FFF",
  black: "#000000",
  gray: "#818181",
  pendingcolor: "red",
  close_color: "#CACACA",
  placeholderTitle: "#818181",
  rejectedcolor: "#D64D49",
  activecolor: "#4CAF50",
  selectionColor: "#121212",
};
